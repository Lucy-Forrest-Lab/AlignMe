#!/bin/bash

python ../../scripts/determine_anchor_strength.py  call_alignme.sh  1.0  extracted.txt ../matrices/vtml.mat