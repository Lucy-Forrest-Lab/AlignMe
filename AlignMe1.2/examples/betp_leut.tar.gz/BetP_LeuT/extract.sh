../../scripts/extract_anchors_from_alignment.py -f msa_alignment/AlignMe_aligned_sequences_of_9281_1415260509.aln
